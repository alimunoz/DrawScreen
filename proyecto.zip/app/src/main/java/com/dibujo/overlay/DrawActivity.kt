package com.dibujo.overlay

import android.app.Activity
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.*

class DrawActivity : Activity() {
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int = 16) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(c) }

    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try { init() } catch (e: Throwable) { Toast.makeText(this, "Error: $e", Toast.LENGTH_LONG).show(); finish() }
    }

    @Suppress("DEPRECATION")
    private fun init() {
        val bmp = Shared.bmp ?: run { finish(); return }
        val lp = window.attributes; lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES; window.attributes = lp
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val v = DrawView(this, bmp)
        val root = FrameLayout(this); root.addView(v, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        fun chip(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(0x33FFFFFF); setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        }
        fun hscroll(row: LinearLayout) = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }

        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xDD1E1E1E.toInt()); setPadding(dp(8), dp(6), dp(8), dp(10)) }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Pinceles
        val names = listOf("Lápiz", "Marcador", "Resaltador", "Aerógrafo", "Caligrafía", "Neón", "Punteado", "Goma")
        val bc = ArrayList<TextView>(); val brushRow = LinearLayout(this)
        fun refresh() = bc.forEachIndexed { i, c -> c.background = rounded(if (i == v.brush) 0xFF3D5AFE.toInt() else 0x33FFFFFF) }
        names.forEachIndexed { i, n -> val c = chip(n) { v.brush = i; refresh() }; bc.add(c); brushRow.addView(c) }
        refresh()

        // Colores
        val cur = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), 0, dp(10), 0) } }
        fun setColor(c: Int) { v.color = c; cur.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(2), Color.WHITE) } }
        setColor(Color.RED)
        val colorRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; addView(cur) }
        listOf(Color.BLACK, Color.WHITE, 0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(), 0xFF00BCD4.toInt(),
            0xFF2196F3.toInt(), 0xFF3F51B5.toInt(), 0xFF9C27B0.toInt(), 0xFFE91E63.toInt(), 0xFF795548.toInt(), 0xFF9E9E9E.toInt()).forEach { col ->
            colorRow.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(3), 0, dp(3), 0) }
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col); setStroke(dp(1), 0x88FFFFFF.toInt()) }
                setOnClickListener { setColor(col) }
            })
        }
        val hue = SeekBar(this).apply {
            max = 360; layoutParams = LinearLayout.LayoutParams(dp(180), WRAP_CONTENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) setColor(Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f))) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        colorRow.addView(hue)
        v.onPick = { setColor(it) }

        // Tamaño
        val size = SeekBar(this).apply {
            max = 80; progress = 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { v.size = (p + 2) * bmp.width / 1080f }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        v.size = (12 + 2) * bmp.width / 1080f
        val sizeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL
            addView(TextView(context).apply { text = "Grosor"; setTextColor(Color.WHITE) })
            addView(size, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) }

        tools.addView(hscroll(brushRow)); tools.addView(hscroll(colorRow)); tools.addView(sizeRow)

        // Acciones
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER }
        actions.addView(chip("↩") { v.undo() }); actions.addView(chip("↪") { v.redo() })
        actions.addView(chip("💧 Gotero") { v.pick = true; Toast.makeText(this, "Toca la pantalla para elegir un color", Toast.LENGTH_SHORT).show() })
        actions.addView(chip("💾 Guardar") { save(v.compose()) })
        actions.addView(chip("☰") { tools.visibility = if (tools.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        actions.addView(chip("✕") { finish() })
        panel.addView(actions); panel.addView(tools)
        root.addView(panel, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun save(b: Bitmap) {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "dibujo_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DibujoOverlay")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri != null) contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        Toast.makeText(this, if (uri != null) "Guardado en Imágenes/DibujoOverlay" else "Error al guardar", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() { Shared.bmp = null; super.onDestroy() }
}
