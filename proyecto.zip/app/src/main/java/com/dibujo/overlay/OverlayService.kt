package com.dibujo.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView

object Shared { var bmp: Bitmap? = null }

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var btn: TextView? = null
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var held: Image? = null
    private val lock = Any()
    private var w = 0
    private var h = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (proj != null || i == null) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Dibujo Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ov").setContentTitle("Dibujo Overlay activo")
            .setContentText("Toca el botón flotante para capturar").setSmallIcon(android.R.drawable.ic_menu_edit).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        w = b.width(); h = b.height()
        val data = i.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(MediaProjectionManager::class.java)
        proj = mpm.getMediaProjection(i.getIntExtra("code", Activity.RESULT_OK), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r ->
            try {
                val im = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                synchronized(lock) { held?.close(); held = im }
            } catch (e: Exception) {}
        }, handler)
        vd = proj!!.createVirtualDisplay("cap", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        addButton()
        return START_NOT_STICKY
    }

    private fun addButton() {
        val s = (58 * resources.displayMetrics.density).toInt()
        val t = TextView(this).apply {
            text = "✎"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE6FF4081.toInt()); setStroke(4, Color.WHITE) }
        }
        val lp = WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 400 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var t0 = 0L
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; t0 = System.currentTimeMillis() }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (moved || Math.abs(dx) > 15 || Math.abs(dy) > 15) { moved = true; lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(t, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (System.currentTimeMillis() - t0 > 800) stopSelf() else capture() }
            }
            true
        }
        wm.addView(t, lp); btn = t
    }

    private fun capture() {
        btn?.visibility = View.INVISIBLE
        handler.postDelayed({
            val bmp = grab()
            btn?.visibility = View.VISIBLE
            if (bmp != null) {
                Shared.bmp = bmp
                startActivity(Intent(this, DrawActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }, 350)
    }

    private fun grab(): Bitmap? = synchronized(lock) {
        val im = held ?: return null
        val pl = im.planes[0]
        val buf = pl.buffer; buf.rewind()
        val tmp = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
        tmp.copyPixelsFromBuffer(buf)
        val out = Bitmap.createBitmap(tmp, 0, 0, w, h)
        if (out !== tmp) tmp.recycle()
        out
    }

    override fun onDestroy() {
        btn?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        synchronized(lock) { held?.close(); held = null }
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
