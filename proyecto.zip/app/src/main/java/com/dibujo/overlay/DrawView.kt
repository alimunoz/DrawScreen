package com.dibujo.overlay

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.*

class DrawView(c: Context, val base: Bitmap) : View(c) {
    class Stroke(val brush: Int, val color: Int, val size: Float) { val pts = ArrayList<PointF>() }

    private val strokes = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
    private val sc = Canvas(strokes)
    private val done = ArrayList<Stroke>()
    private val redo = ArrayList<Stroke>()
    private var cur: Stroke? = null
    var brush = 0; var color = Color.RED; var size = 12f
    var pick = false; var onPick: ((Int) -> Unit)? = null
    private val m = Matrix(); private val inv = Matrix()
    private var pickPt: PointF? = null; private var pickCol = 0
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        m.setRectToRect(RectF(0f, 0f, base.width.toFloat(), base.height.toFloat()), RectF(0f, 0f, w.toFloat(), h.toFloat()), Matrix.ScaleToFit.CENTER)
        m.invert(inv)
    }

    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.BLACK)
        cv.save(); cv.concat(m)
        cv.drawBitmap(base, 0f, 0f, bp)
        cv.saveLayer(0f, 0f, base.width.toFloat(), base.height.toFloat(), null)
        cv.drawBitmap(strokes, 0f, 0f, bp)
        cur?.let { render(cv, it) }
        cv.restore(); cv.restore()
        pickPt?.let {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val cy = it.y - 160f
            p.style = Paint.Style.FILL; p.color = pickCol; cv.drawCircle(it.x, cy, 70f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = Color.WHITE; cv.drawCircle(it.x, cy, 70f, p)
            p.strokeWidth = 3f; p.color = Color.BLACK; cv.drawCircle(it.x, it.y, 14f, p)
        }
    }

    private fun smooth(pts: List<PointF>): Path {
        val p = Path(); p.moveTo(pts[0].x, pts[0].y)
        if (pts.size == 1) { p.lineTo(pts[0].x + 0.01f, pts[0].y); return p }
        for (i in 1 until pts.size - 1) p.quadTo(pts[i].x, pts[i].y, (pts[i].x + pts[i + 1].x) / 2, (pts[i].y + pts[i + 1].y) / 2)
        p.lineTo(pts.last().x, pts.last().y)
        return p
    }

    private fun render(cv: Canvas, s: Stroke) {
        if (s.pts.isEmpty()) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.color = s.color; p.strokeWidth = s.size
        when (s.brush) {
            0 -> cv.drawPath(smooth(s.pts), p)
            1 -> { p.alpha = 190; p.strokeWidth = s.size * 1.6f; cv.drawPath(smooth(s.pts), p) }
            2 -> { p.alpha = 90; p.strokeCap = Paint.Cap.SQUARE; p.strokeJoin = Paint.Join.BEVEL; p.strokeWidth = s.size * 3f; cv.drawPath(smooth(s.pts), p) }
            3 -> { // aerógrafo
                p.strokeWidth = max(1.5f, s.size / 10f)
                s.pts.forEachIndexed { i, pt ->
                    val r = Random(i * 7919L + 13)
                    for (k in 0 until 16) {
                        val a = r.nextDouble() * 2 * PI; val d = sqrt(r.nextDouble()) * s.size * 1.6
                        cv.drawPoint(pt.x + (cos(a) * d).toFloat(), pt.y + (sin(a) * d).toFloat(), p)
                    }
                }
            }
            4 -> { // caligrafía (punta plana 45°)
                val dx = (s.size * 0.7f * cos(PI / 4)).toFloat(); val dy = (s.size * 0.7f * sin(PI / 4)).toFloat()
                p.style = Paint.Style.FILL_AND_STROKE; p.strokeWidth = 1f
                val pts = if (s.pts.size == 1) listOf(s.pts[0], PointF(s.pts[0].x + 0.1f, s.pts[0].y)) else s.pts
                for (i in 1 until pts.size) {
                    val a = pts[i - 1]; val b = pts[i]
                    val q = Path(); q.moveTo(a.x - dx, a.y + dy); q.lineTo(a.x + dx, a.y - dy); q.lineTo(b.x + dx, b.y - dy); q.lineTo(b.x - dx, b.y + dy); q.close()
                    cv.drawPath(q, p)
                }
            }
            5 -> { // neón
                val path = smooth(s.pts)
                p.strokeWidth = s.size * 2f; p.maskFilter = BlurMaskFilter(max(2f, s.size * 1.2f), BlurMaskFilter.Blur.NORMAL)
                cv.drawPath(path, p); cv.drawPath(path, p)
                val core = Paint(p); core.maskFilter = null; core.strokeWidth = max(2f, s.size * 0.5f)
                core.color = ColorUtilsLite.mix(s.color, Color.WHITE, 0.85f); cv.drawPath(path, core)
            }
            6 -> { p.pathEffect = DashPathEffect(floatArrayOf(0.1f, s.size * 2f), 0f); cv.drawPath(smooth(s.pts), p) }
            7 -> { p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR); p.strokeWidth = s.size * 2f; cv.drawPath(smooth(s.pts), p) }
        }
    }

    private fun rebuild() { strokes.eraseColor(0); done.forEach { render(sc, it) }; invalidate() }
    fun undo() { if (done.isNotEmpty()) { redo.add(done.removeAt(done.size - 1)); rebuild() } }
    fun redo() { if (redo.isNotEmpty()) { done.add(redo.removeAt(redo.size - 1)); rebuild() } }
    fun compose(): Bitmap { val o = base.copy(Bitmap.Config.ARGB_8888, true); Canvas(o).drawBitmap(strokes, 0f, 0f, null); return o }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val p = floatArrayOf(e.x, e.y); inv.mapPoints(p)
        if (pick) {
            pickPt = PointF(e.x, e.y)
            pickCol = base.getPixel(p[0].toInt().coerceIn(0, base.width - 1), p[1].toInt().coerceIn(0, base.height - 1)) or (0xFF shl 24)
            if (e.actionMasked == MotionEvent.ACTION_UP) { pick = false; pickPt = null; onPick?.invoke(pickCol) }
            invalidate(); return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { cur = Stroke(brush, color, size).also { it.pts.add(PointF(p[0], p[1])) }; redo.clear() }
            MotionEvent.ACTION_MOVE -> cur?.let {
                val l = it.pts.last(); val lx = l.x; val ly = l.y
                val d = hypot(p[0] - lx, p[1] - ly); val step = max(size / 4f, 2f)
                if (d >= step) { val n = (d / step).toInt(); for (k in 1..n) it.pts.add(PointF(lx + (p[0] - lx) * k / n, ly + (p[1] - ly) * k / n)) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { cur?.let { render(sc, it); done.add(it) }; cur = null }
        }
        invalidate(); return true
    }
}

object ColorUtilsLite {
    fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
}
