package com.dibujo.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = TextView(this).apply {
            text = "Dibujo Overlay\n\n1) Permite \"Mostrar sobre otras apps\"\n2) Acepta la captura de pantalla\n3) Toca el botón flotante ✎ para capturar y dibujar.\n\nMantén pulsado el botón flotante para cerrarlo."
            textSize = 17f; setPadding(48, 96, 48, 48)
        }
        val btn = Button(this).apply { text = "Iniciar"; setOnClickListener { start() } }
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(t); addView(btn) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2); return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { start() }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data))
            finish()
        }
    }
}
